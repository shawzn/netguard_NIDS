import streamlit as st
from src import ui, views
from src.config import APP_NAME
st.set_page_config(page_title="NetGuard NIDS", page_icon="🛡", layout="wide")
ui.css()
NAV = {"MENU": [("Overview Dashboard", views.dashboard), ("Dataset Analysis", views.dataset_analysis), ("Model Performance", views.ml), ("Intrusion Scanner", views.scanner)]}
PAGES = {n: f for g in NAV.values() for n, f in g}
page = st.session_state.setdefault("page", "Overview Dashboard")
with st.sidebar:
    st.markdown('<div class="brand">NET<b>GUARD</b></div><div class="sub">Network Security Monitoring</div>', unsafe_allow_html=True)
    for g, items in NAV.items():
        st.markdown(f'<div class="grp">{g}</div>', unsafe_allow_html=True)
        for n, _ in items: st.button(n, key=f"nav_{n}", type="primary" if n == page else "secondary", on_click=st.session_state.update, kwargs=dict(page=n))
c = views.ctx()
a, b = st.columns([6, 1])
a.markdown(f'<div class="hdr"><h2>{page}</h2><div>{ui.badge("App: running","ok")}{ui.badge("Mode: "+c["mode"],"warn" if c["mode"]=="demo" else "info")}{ui.badge("Model: available" if c["pipe"] else "Model: unavailable","ok" if c["pipe"] else "crit")}</div></div>', unsafe_allow_html=True)
if b.button("Refresh", use_container_width=True): st.cache_data.clear(); st.rerun()
if c["mode"] == "demo": st.info("DEMO MODE: no trained model loaded. Sample data is synthetic and inference is disabled.")
elif c["pipe"] is None: st.error(f"Production mode: model failed to load. {c['err']}")
PAGES[page](c)
