import streamlit as st
from src import ui, views
st.set_page_config(page_title="NetGuard NIDS", page_icon="🛡", layout="wide", initial_sidebar_state="collapsed")
ui.css()
PAGES = {"Overview Dashboard": (views.dashboard, 'Detection summary and scan history for this session.'), "Dataset Analysis": (views.dataset_analysis, 'Characteristics of the dataset used to train and evaluate the model.'),
         "Model Performance": (views.ml, 'XGBoost evaluation results from real training artifacts.'), "Intrusion Scanner": (views.scanner, 'Upload a CSV and classify up to 20 records offline.')}
page = st.session_state.setdefault("page", "Overview Dashboard")
c = views.ctx()
with st.container(key="topbar"):
    a, b, d = st.columns([1.7, 5.3, 3])
    a.markdown('<div class="logo"><span class="sq">NG</span>NET<i>//</i>GUARD</div>', unsafe_allow_html=True)
    for col, n in zip(b.columns(len(PAGES)), PAGES):
        col.button(n, key=f"nav_{n}", type="primary" if n == page else "secondary", use_container_width=True, on_click=st.session_state.update, kwargs=dict(page=n))
    d.markdown(f'<div style="text-align:right">{ui.badge("App: running","ok")}{ui.badge("Mode: "+c["mode"],"warn" if c["mode"]=="demo" else "info")}{ui.badge("Model: available" if c["pipe"] else "Model: unavailable","ok" if c["pipe"] else "crit")}</div>', unsafe_allow_html=True)
ui.reset()
st.markdown(f'<span class="tagb">NETGUARD // {c["mode"].upper()}</span><div class="h1">{page.upper()}</div><p class="lead">{PAGES[page][1]}</p>', unsafe_allow_html=True)
if c["mode"] == "demo": st.info("DEMO MODE: no trained model loaded. Sample data is synthetic and inference is disabled.")
elif c["pipe"] is None: st.error(f"Production mode: model failed to load. {c['err']}")
PAGES[page][0](c)
st.markdown('<div class="foot"><span>NETGUARD // NIDS © 2026</span><span>Academic project. Offline CSV analysis only.</span></div>', unsafe_allow_html=True)
