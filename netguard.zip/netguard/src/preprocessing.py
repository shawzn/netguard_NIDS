def to_model_input(df, schema):
    """Column selection/order only. Encoding/scaling lives INSIDE the serialized pipeline (same as training)."""
    return df[list(schema)]
