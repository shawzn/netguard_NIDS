import uuid, pandas as pd, streamlit as st
from datetime import datetime
COLS = ["timestamp", "source_ip", "destination_ip", "protocol", "predicted_class", "model_score", "scan_id"]
def get(): return st.session_state.setdefault("history", pd.DataFrame(columns=COLS))
def add(raw, res):
    sid = uuid.uuid4().hex[:8]
    h = pd.DataFrame({"timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "scan_id": sid}, index=raw.index)
    for k, cands in {"source_ip": ["src_ip", "source_ip"], "destination_ip": ["dst_ip", "destination_ip"], "protocol": ["protocol_type", "protocol"]}.items():
        h[k] = next((raw[c] for c in cands if c in raw), None)
    h = pd.concat([h, res], axis=1)[COLS]
    st.session_state["history"] = pd.concat([get(), h], ignore_index=True)
    return sid
