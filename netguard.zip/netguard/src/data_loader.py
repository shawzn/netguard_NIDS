import json, pandas as pd
from .config import *
def load_schema():
    if SCHEMA_PATH.exists():
        return json.loads(SCHEMA_PATH.read_text())["features"], "models/feature_schema.json"
    return DEMO_SCHEMA, "built-in demo schema (NSL-KDD, 41 features)"
def load_dataset():
    p = DATASET_PATH if DATASET_PATH.exists() else SAMPLE_PATH
    return (pd.read_csv(p), p.name, p != DATASET_PATH) if p.exists() else (None, None, True)
def label_col(df):
    return next((c for c in df.columns if c.lower() in TARGET_COLS[:4]), None) if df is not None else None
def load_json(name):
    p = ARTIFACTS / name
    return json.loads(p.read_text()) if p.exists() else None
