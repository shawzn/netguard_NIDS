import streamlit as st, plotly.express as px
from .config import THEME as T
def css():
    st.markdown(f"""<style>
@import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@800&family=DM+Sans:wght@400;500;600&family=DM+Mono:wght@400;500&display=swap');
html,body,.stApp,[class*="css"]{{font-family:'DM Sans',sans-serif;font-size:13px}}
.stApp{{background:{T['bg']}}} header[data-testid="stHeader"],footer,#MainMenu{{display:none}}
.block-container{{padding:.8rem 1.4rem;max-width:100%}}
[data-testid="stSidebar"]{{background:{T['ink']};min-width:230px;max-width:230px}} [data-testid="stSidebar"] *{{color:#ddd}}
.brand{{font-family:'Bricolage Grotesque';font-weight:800;font-size:20px;color:#fff;letter-spacing:.5px}} .brand b{{color:{T['accent']}}}
.sub,.grp,.lbl,.kl,.ph span,.tag,.tag2,.b{{font-family:'DM Mono',monospace;text-transform:uppercase;letter-spacing:.08em;font-size:10px}}
.grp{{color:#888;margin:14px 0 4px}}
[data-testid="stSidebar"] button{{width:100%;justify-content:flex-start;border:0;border-left:3px solid transparent;border-radius:0;background:transparent;padding:4px 10px;min-height:0}}
[data-testid="stSidebar"] button p{{font-size:13px;text-align:left}}
[data-testid="stSidebar"] button[kind="primary"],[data-testid="stSidebar"] button[data-testid="stBaseButton-primary"]{{background:#222;border-left-color:{T['accent']};color:#fff}}
.hdr{{background:{T['panel']};border:2px solid {T['ink']};box-shadow:3px 3px 0 {T['ink']};padding:6px 12px;display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}}
.hdr h2{{font-family:'Bricolage Grotesque';font-weight:800;font-size:16px;margin:0}}
.b{{display:inline-block;padding:2px 6px;border:1px solid {T['ink']};margin-left:6px;background:{T['muted']}}}
.b.ok{{background:{T['ok']};color:#fff}} .b.warn{{background:{T['warn']}}} .b.crit{{background:{T['crit']};color:#fff}} .b.info{{background:{T['info']};color:#fff}}
.kpi{{background:{T['panel']};border:1px solid {T['border']};border-top:3px solid {T['accent']};padding:6px 10px}}
.kl{{color:#666}} .kv{{font-size:22px;font-weight:600}} .ks{{font-size:11px;color:#777}}
.ph{{border-bottom:1px solid {T['ink']};font-weight:600;padding-bottom:3px;margin-bottom:6px;display:flex;justify-content:space-between}} .ph span{{color:#777;font-weight:400}}
.empty{{background:{T['muted']};border:1px dashed #999;padding:14px;color:#555;text-align:center}}
[data-testid="stVerticalBlockBorderWrapper"]{{background:{T['panel']};border-radius:2px!important}}
.stButton>button,.stDownloadButton>button{{border-radius:2px}}
</style>""", unsafe_allow_html=True)
def kpis(items):
    for c, (l, v, s) in zip(st.columns(len(items)), items):
        c.markdown(f'<div class="kpi"><div class="kl">{l}</div><div class="kv">{v}</div><div class="ks">{s}</div></div>', unsafe_allow_html=True)
def panel(t, meta=""): st.markdown(f'<div class="ph">{t}<span>{meta}</span></div>', unsafe_allow_html=True)
def badge(t, k=""): return f'<span class="b {k}">{t}</span>'
def empty(m): st.markdown(f'<div class="empty">{m}</div>', unsafe_allow_html=True)
COL = {"Normal": T["ok"], "Anomaly": T["crit"]}
def bar(counts):
    d = counts.rename_axis("class").reset_index(name="records"); d["class"] = d["class"].astype(str)
    f = px.bar(d, x="class", y="records", color="class", color_discrete_map=COL)
    f.update_layout(height=230, margin=dict(l=0, r=0, t=6, b=0), showlegend=False, paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font=dict(size=11))
    st.plotly_chart(f, use_container_width=True)
