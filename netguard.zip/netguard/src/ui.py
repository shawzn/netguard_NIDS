import streamlit as st, plotly.express as px
from .config import THEME as T
def css():
    st.markdown(f"""<style>
@import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@800&family=DM+Sans:wght@400;500;600&family=DM+Mono:wght@400;500&display=swap');
html,body,.stApp,[class*="css"]{{font-family:'DM Sans',sans-serif;font-size:13px}}
.stApp{{background:{T['bg']}}} header[data-testid="stHeader"],footer,#MainMenu{{display:none}}
.b{{display:inline-block;padding:2px 6px;border:1px solid {T['ink']};margin-left:6px;background:{T['muted']}}}
.b.ok{{background:{T['ok']};color:#fff}} .b.warn{{background:{T['warn']}}} .b.crit{{background:{T['crit']};color:#fff}} .b.info{{background:{T['info']};color:#fff}}
.kpi{{background:{T['panel']};border:1px solid {T['border']};border-top:3px solid {T['accent']};padding:6px 10px}}
.kl{{color:#666}} .kv{{font-size:22px;font-weight:600}} .ks{{font-size:11px;color:#777}}
.empty{{background:{T['muted']};border:1px dashed #999;padding:14px;color:#555;text-align:center}}
[data-testid="stVerticalBlockBorderWrapper"]{{background:{T['panel']};border-radius:2px!important}}
.stButton>button,.stDownloadButton>button{{border-radius:2px}}

.sub,.lbl,.kl,.ph span,.tagb,.b,.foot{{font-family:'DM Mono',monospace;text-transform:uppercase;letter-spacing:.08em;font-size:10px}}
.stApp{{background-image:linear-gradient(rgba(0,0,0,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(0,0,0,.04) 1px,transparent 1px);background-size:24px 24px}}
[data-testid="stSidebar"],[data-testid="collapsedControl"],[data-testid="stSidebarCollapsedControl"]{{display:none}}
.block-container{{max-width:1120px;margin:auto;padding:0 1rem 1rem}}
.st-key-topbar{{background:{T['panel']};border:2px solid {T['ink']};box-shadow:3px 3px 0 {T['ink']};padding:6px 10px;margin:14px 0 22px}}
.st-key-topbar button{{border:1.5px solid {T['ink']};border-radius:0;min-height:0;padding:4px 6px;background:{T['panel']};color:{T['ink']}}}
.st-key-topbar button p{{font-family:'DM Mono';text-transform:uppercase;letter-spacing:.06em;font-size:11px}}
.st-key-topbar button[kind="primary"],.st-key-topbar button[data-testid="stBaseButton-primary"]{{background:{T['ink']};color:#fff}}
.logo{{font-family:'Bricolage Grotesque';font-weight:800;font-size:18px;white-space:nowrap}} .logo i{{color:{T['accent']};font-style:normal}}
.logo .sq{{background:{T['accent']};border:2px solid {T['ink']};padding:2px 6px;margin-right:8px;box-shadow:2px 2px 0 {T['ink']}}}
.tagb{{background:{T['ink']};color:{T['accent']};padding:5px 9px;display:inline-block}}
.h1{{font-family:'Bricolage Grotesque';font-weight:800;font-size:44px;line-height:1;margin:8px 0}} .lead{{color:#555;font-size:14px;margin:0 0 14px}}
.ph{{border-bottom:1px solid {T['ink']};padding-bottom:4px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;font-family:'Bricolage Grotesque';font-weight:800;text-transform:uppercase;font-size:15px}}
.ph span{{color:#777}} .n{{font:10px 'DM Mono';font-style:normal;background:{T['ink']};color:{T['accent']};padding:2px 5px;margin-right:8px}}
.kpi{{box-shadow:3px 3px 0 {T['ink']}}}
.empty{{border:1px dashed {T['ink']};background:rgba(255,255,255,.6)}} .empty b{{display:block;color:{T['accent']};font:22px 'DM Mono'}}
.foot{{border-top:1px solid {T['ink']};background:{T['panel']};display:flex;justify-content:space-between;padding:12px 16px;margin:32px -1rem 0;color:#555}}
</style>""", unsafe_allow_html=True)
def kpis(items):
    for c, (l, v, s) in zip(st.columns(len(items)), items):
        c.markdown(f'<div class="kpi"><div class="kl">{l}</div><div class="kv">{v}</div><div class="ks">{s}</div></div>', unsafe_allow_html=True)
_n = [0]
def reset(): _n[0] = 0
def panel(t, meta=""):
    _n[0] += 1; st.markdown(f'<div class="ph"><div><i class="n">{_n[0]:02d}</i>{t}</div><span>{meta}</span></div>', unsafe_allow_html=True)
def badge(t, k=""): return f'<span class="b {k}">{t}</span>'
def empty(m): st.markdown(f'<div class="empty"><b>[ ]</b>{m}</div>', unsafe_allow_html=True)
COL = {"Normal": T["ok"], "Anomaly": T["crit"]}
def bar(counts):
    d = counts.rename_axis("class").reset_index(name="records"); d["class"] = d["class"].astype(str)
    f = px.bar(d, x="class", y="records", color="class", color_discrete_map=COL)
    f.update_layout(height=230, margin=dict(l=0, r=0, t=6, b=0), showlegend=False, paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font=dict(size=11))
    st.plotly_chart(f, use_container_width=True)
