import joblib, pandas as pd
from .config import MODEL_PATH, CLASS_MAP
def load_model():
    try: return joblib.load(MODEL_PATH), None
    except Exception as e: return None, f"{type(e).__name__}: {e}"
def predict(pipe, X):
    score = pipe.predict_proba(X)[:, 1]; pred = pipe.predict(X)
    return pd.DataFrame({"predicted_class": [CLASS_MAP.get(int(p), str(p)) for p in pred], "model_score": score.round(4)}, index=X.index)
