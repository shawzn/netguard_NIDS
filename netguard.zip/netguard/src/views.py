import sys, platform, io, pandas as pd, numpy as np, streamlit as st, plotly.express as px
from . import history, predictor, ui
from .config import *
from .data_loader import load_dataset, load_schema, label_col, load_json
from .preprocessing import to_model_input
from .validator import validate

@st.cache_resource
def model(): return predictor.load_model() if MODEL_PATH.exists() else (None, "Model file not found: models/netguard_pipeline.joblib")
@st.cache_data
def dataset(): return load_dataset()
def ctx():
    mode = app_mode(); pipe, err = model(); df, name, sample = dataset(); schema, src = load_schema()
    return dict(mode=mode, pipe=pipe, err=err, df=df, name=name, sample=sample, schema=schema, schema_src=src, lab=label_col(df))
def table(df, h=360): st.dataframe(df, use_container_width=True, hide_index=True, height=h)
def need(df, msg):
    if df is None or len(df) == 0: ui.empty(msg); return True

def dashboard(c):
    h = history.get(); an = int((h.predicted_class == "Anomaly").sum()) if len(h) else 0
    ui.kpis([("Total analyzed", len(h), "records scanned this session"), ("Normal", len(h) - an, "predicted"), ("Anomaly", an, "predicted"),
             ("Model", "Loaded" if c["pipe"] else "Unavailable", c["mode"].upper()), ("Backend", "Running", "Streamlit app process")])
    a, b = st.columns(2)
    with a, st.container(border=True):
        ui.panel("Detection distribution", "model predictions, current session")
        ui.bar(h.predicted_class.value_counts()) if len(h) else ui.empty("No scans yet. Run one in Intrusion Scanner.")
    with b, st.container(border=True):
        ui.panel("System status")
        table(pd.DataFrame([("Mode", c["mode"].upper()), ("Model", "Loaded" if c["pipe"] else f"Unavailable ({c['err']})"),
            ("Dataset", f"{c['name']} ({'sample' if c['sample'] else 'local'})" if c["df"] is not None else "Unavailable"),
            ("Input", "Uploaded CSV only (no live capture)")], columns=["item", "value"]), 175)
    with st.container(border=True):
        ui.panel("Scan history", "current session"); table(h.iloc[::-1], 260) if len(h) else ui.empty("No scan activity recorded.")

def dataset_analysis(c):
    df = c["df"]
    if need(df, "No dataset available."): return
    ui.kpis([("Dataset", c["name"], "bundled sample (synthetic)" if c["sample"] else "local file"), ("Records", f"{len(df):,}", ""), ("Columns", df.shape[1], f"{len(c['schema'])} model features"),
             ("Missing values", int(df.isna().sum().sum()), ""), ("Duplicates", int(df.duplicated().sum()), "")])
    a, b = st.columns(2)
    with a, st.container(border=True):
        ui.panel("Class distribution"); ui.bar(df[c["lab"]].astype(str).value_counts()) if c["lab"] else ui.empty("No label column.")
    with b, st.container(border=True):
        ui.panel("Schema"); table(pd.DataFrame({"column": df.columns, "dtype": df.dtypes.astype(str).values, "missing": df.isna().sum().values}), 230)
    num = df.select_dtypes("number")
    if num.shape[1] > 1:
        with st.container(border=True):
            ui.panel("Numerical correlation", "first 25 numeric columns")
            st.plotly_chart(px.imshow(num.iloc[:, :25].corr(), color_continuous_scale="RdBu_r", zmin=-1, zmax=1, height=420), use_container_width=True)
        with st.container(border=True):
            ui.panel("Feature distribution"); f = st.selectbox("Feature", num.columns); st.plotly_chart(px.histogram(df, x=f, height=250, color_discrete_sequence=[THEME["accent"]]), use_container_width=True)
    s = load_json("smotenc_comparison.json")
    with st.container(border=True):
        ui.panel("SMOTENC: before vs after")
        if s: ui.bar(pd.Series({**{f"before: {k}": v for k, v in s["before"].items()}, **{f"after: {k}": v for k, v in s["after"].items()}}))
        else: ui.empty("artifacts/smotenc_comparison.json not found.")

def ml(c):
    m = load_json("metrics.json")
    if not m: return ui.empty("No evaluation artifacts (artifacts/metrics.json). No metrics are shown or generated in Demo Mode.")
    k = m.get("metrics", {})
    ui.kpis([("Model", m.get("model_name", "–"), m.get("model_version", "")), ("Training dataset", m.get("training_dataset", "–"), f"{m.get('n_features', '–')} features")] + [(n.title(), f"{k[n]:.4f}", "") for n in ("accuracy", "precision", "recall", "f1") if n in k])
    a, b = st.columns(2)
    with a, st.container(border=True):
        ui.panel("Confusion matrix")
        if "confusion_matrix" in m: st.plotly_chart(px.imshow(m["confusion_matrix"], text_auto=True, x=["Normal", "Anomaly"], y=["Normal", "Anomaly"], labels=dict(x="Predicted", y="Actual"), color_continuous_scale="Oranges", height=300), use_container_width=True)
    with b, st.container(border=True):
        ui.panel("Feature importance")
        p = ARTIFACTS / "feature_importance.csv"
        if p.exists(): fi = pd.read_csv(p).nlargest(15, "importance"); st.plotly_chart(px.bar(fi, x="importance", y="feature", orientation="h", height=300).update_yaxes(autorange="reversed"), use_container_width=True)
        else: ui.empty("feature_importance.csv not found.")
    if "baseline" in m and "smotenc" in m:
        with st.container(border=True): ui.panel("Baseline vs SMOTENC"); table(pd.DataFrame({"baseline": m["baseline"], "smotenc": m["smotenc"]}).reset_index(names="metric"), 200)

def scanner(c):
    st.warning(f"Offline classification of uploaded records (max {MAX_RECORDS}). This is NOT live packet capture.")
    if not c["pipe"]: st.error("Inference disabled: " + (c["err"] or "model unavailable") + (" (Demo Mode)" if c["mode"] == "demo" else ""))
    up = st.file_uploader("Upload CSV", type="csv"); dm = st.checkbox("Drop records with missing values")
    st.download_button("Download sample CSV", SAMPLE_PATH.read_bytes(), "sample_traffic.csv") if SAMPLE_PATH.exists() else None
    if not up: return
    try: raw = pd.read_csv(up)
    except Exception as e: return st.error(f"Cannot parse CSV: {e}")
    clean, err, warn = validate(raw, c["schema"], dm)
    for w in warn: st.info(w)
    for e in err: st.error(e)
    with st.container(border=True): ui.panel("Data preview", f"{len(raw)} records"); table(raw.head(20), 220)
    if clean is None: return
    if st.button("Run scan", type="primary", disabled=c["pipe"] is None):
        res = predictor.predict(c["pipe"], to_model_input(clean, c["schema"])); sid = history.add(clean, res)
        out = pd.concat([clean, res], axis=1); lab = label_col(out)
        if lab: out = out.rename(columns={lab: f"ground_truth_{lab}"}); st.caption("ground_truth_* is the file's own label, shown for comparison only; predicted_class is the model output.")
        with st.container(border=True):
            ui.panel("Results", f"scan {sid}"); table(out[[*res.columns, *[x for x in out if x.startswith("ground_truth")], *list(c["schema"])]], 300)
        st.download_button("Download results CSV", out.to_csv(index=False), f"netguard_scan_{sid}.csv")
