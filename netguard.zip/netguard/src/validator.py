import pandas as pd
from .config import MAX_RECORDS, TARGET_COLS
def validate(df, schema, drop_missing=False):
    """Returns (clean_df | None, errors, warnings). Incompatible schemas are never silently accepted."""
    err, warn = [], []
    if df.empty: return None, ["File contains no records."], warn
    if len(df) > MAX_RECORDS: return None, [f"{len(df)} records uploaded; maximum is {MAX_RECORDS} per scan."], warn
    df = df.copy(); df.columns = [c.strip() for c in df.columns]
    miss = [c for c in schema if c not in df.columns]
    if miss: return None, [f"Missing required columns ({len(miss)}): {', '.join(miss)}"], warn
    extra = [c for c in df.columns if c not in schema]
    ign = [c for c in extra if c.lower() in TARGET_COLS]
    if ign: warn.append(f"Label column(s) {ign} kept as ground truth only; never used as model input.")
    oth = [c for c in extra if c not in ign]
    if oth: warn.append(f"Ignored non-schema columns: {', '.join(oth)}")
    for c, t in schema.items():
        if t == "numeric":
            conv = pd.to_numeric(df[c], errors="coerce")
            bad = conv.isna() & df[c].notna()
            if bad.any(): err.append(f"'{c}': non-numeric values in rows {list((df.index[bad] + 1)[:5])}")
            df[c] = conv
    na = df[list(schema)].isna().any(axis=1)
    if na.any():
        if drop_missing: warn.append(f"Dropped {int(na.sum())} record(s) with missing values."); df = df[~na]
        else: err.append(f"{int(na.sum())} record(s) have missing values. Fix the file or enable 'drop records with missing values'.")
    return (None if err or df.empty else df), err, warn
