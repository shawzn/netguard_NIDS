import os
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
APP_NAME, APP_VERSION, MAX_RECORDS = "NetGuard", "0.1.0", 20
MODEL_PATH = ROOT / "models/netguard_pipeline.joblib"
SCHEMA_PATH = ROOT / "models/feature_schema.json"   # {"features": {"col": "numeric|categorical"}}
ARTIFACTS = ROOT / "artifacts"                       # metrics.json, feature_importance.csv, smotenc_comparison.json
DATASET_PATH, SAMPLE_PATH = ROOT / "data/dataset.csv", ROOT / "data/sample_traffic.csv"
TARGET_COLS = ["label", "class", "attack", "target", "difficulty"]  # never used as features
CLASS_MAP = {0: "Normal", 1: "Anomaly"}
# Centralized theme: green enterprise palette (edit freely)
THEME = dict(ink="#0E2418", bg="#EEF2EC", panel="#FFFFFF", muted="#DDE6DA", accent="#2FA05A",
             ok="#1E8E3E", warn="#E8A200", crit="#D32F2F", info="#1A73E8", border="#C3CFBF")
NSL = ("duration protocol_type service flag src_bytes dst_bytes land wrong_fragment urgent hot num_failed_logins "
       "logged_in num_compromised root_shell su_attempted num_root num_file_creations num_shells num_access_files "
       "num_outbound_cmds is_host_login is_guest_login count srv_count serror_rate srv_serror_rate rerror_rate "
       "srv_rerror_rate same_srv_rate diff_srv_rate srv_diff_srv_rate dst_host_count dst_host_srv_count "
       "dst_host_same_srv_rate dst_host_diff_srv_rate dst_host_same_src_port_rate dst_host_srv_diff_host_rate "
       "dst_host_serror_rate dst_host_srv_serror_rate dst_host_rerror_rate dst_host_srv_rerror_rate").split()
DEMO_SCHEMA = {c: "categorical" if c in ("protocol_type", "service", "flag") else "numeric" for c in NSL}
def app_mode():
    m = os.getenv("NETGUARD_MODE", "auto").lower()
    return m if m in ("demo", "production") else ("production" if MODEL_PATH.exists() else "demo")
