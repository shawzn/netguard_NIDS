# NetGuard — NIDS console (Streamlit + XGBoost)
Run: `pip install -r requirements.txt && streamlit run app.py`

**Modes** (`NETGUARD_MODE=auto|demo|production`): auto = production if `models/netguard_pipeline.joblib` exists, else demo (no inference, no metrics, synthetic sample data only).

**Production artifacts**
- `models/netguard_pipeline.joblib` — full sklearn Pipeline (preprocessing + XGBClassifier; `predict`/`predict_proba`, class 1 = Anomaly)
- `models/feature_schema.json` — `{"features": {"col": "numeric"|"categorical"}}` (else the NSL-KDD 41-feature demo schema is used)
- `artifacts/metrics.json` — `{model_name, model_version, training_dataset, n_features, metrics:{accuracy,precision,recall,f1}, confusion_matrix:[[tn,fp],[fn,tp]], baseline:{}, smotenc:{}}`
- `artifacts/feature_importance.csv` (feature,importance), `artifacts/smotenc_comparison.json` (`{before:{}, after:{}}`), `data/dataset.csv`


**Deploy (Streamlit Community Cloud)**: push to GitHub, create app with main file `app.py`, set `NETGUARD_MODE` if needed. Commit model files (or use Git LFS) for production.

Scan history is per session (in memory). The scanner processes uploaded CSVs only; no live capture.
