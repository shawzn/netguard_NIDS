"""Load and perform a first audit of standard NSL-KDD files."""

from pathlib import Path

import pandas as pd

from .schema import NSL_KDD_COLUMNS, FEATURE_COLUMNS, CATEGORICAL_COLUMNS

ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = ROOT / "data" / "raw"
TRAIN_PATH = RAW_DIR / "KDDTrain+.txt"
TEST_PATH = RAW_DIR / "KDDTest+.txt"


def load_standard_nsl_kdd(path: Path) -> pd.DataFrame:
    """Read the standard 43-column, headerless NSL-KDD text/CSV file."""
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset file not found: {path}\n"
            "Place KDDTrain+.txt and KDDTest+.txt inside data/raw/."
        )

    df = pd.read_csv(
        path,
        header=None,
        names=NSL_KDD_COLUMNS,
        skipinitialspace=True,
    )

    # Some Kaggle mirrors add a header row even though the canonical files do not.
    if str(df.iloc[0, 0]).strip().lower() == "duration":
        df = df.iloc[1:].reset_index(drop=True)

    if df.shape[1] != len(NSL_KDD_COLUMNS):
        raise ValueError(
            f"Expected {len(NSL_KDD_COLUMNS)} columns, got {df.shape[1]} in {path.name}."
        )

    for column in CATEGORICAL_COLUMNS + ["label"]:
        df[column] = df[column].astype("string").str.strip()

    # A few dataset mirrors retain a trailing period on attack labels.
    df["label"] = df["label"].str.rstrip(".")
    return df


def summarize(name: str, df: pd.DataFrame) -> None:
    print(f"\n{'=' * 72}\n{name}\n{'=' * 72}")
    print(f"Rows: {len(df):,}")
    print(f"Columns: {len(df.columns)} (expected 43 total: 41 features + label + difficulty)")
    print(f"Input features: {len(FEATURE_COLUMNS)}")

    print("\nColumn types:")
    print(df.dtypes.value_counts())

    print("\nMissing values (top 10):")
    missing = df.isna().sum().sort_values(ascending=False)
    print(missing.head(10))

    print(f"\nExact duplicate rows: {df.duplicated().sum():,}")

    print("\nOriginal class distribution:")
    print(df["label"].value_counts(dropna=False).head(20))

    binary = df["label"].str.lower().map(
        lambda value: "normal" if value == "normal" else "anomaly"
    )
    print("\nBinary class distribution (normal vs anomaly):")
    print(binary.value_counts(dropna=False))

    print("\nFirst five rows:")
    print(df.head().to_string(index=False))

    print("\nNumeric summary:")
    print(df[FEATURE_COLUMNS].describe(include="all").transpose().head(12))


def main() -> None:
    train_df = load_standard_nsl_kdd(TRAIN_PATH)
    test_df = load_standard_nsl_kdd(TEST_PATH)

    summarize("KDDTrain+", train_df)
    summarize("KDDTest+", test_df)

    print("\nSchema check:")
    print("Training and testing feature columns match:",
          train_df[FEATURE_COLUMNS].columns.equals(test_df[FEATURE_COLUMNS].columns))
    print("The `difficulty` column will be excluded from model input.")


if __name__ == "__main__":
    main()
