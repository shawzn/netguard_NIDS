# NetGuard — NIDS Machine Learning Starter

Starter repository for a supervised binary Network Intrusion Detection System using NSL-KDD, XGBoost, and Streamlit.

## Project scope

- Input: NSL-KDD connection records (41 input features).
- Target: `normal` or `anomaly` (all non-normal attack labels are mapped to `anomaly`).
- Model: XGBoost Classifier.
- Evaluation: precision, recall, F1-score, confusion matrix, and false-negative review.
- Demo: Streamlit dashboard that accepts an unlabeled CSV containing the same 41 input features.

**Important:** NSL-KDD contains connection-level records, not live packet captures. This project is a supervised benchmark demonstration, not a production IPS and not proof of zero-day detection.

## Expected data files

Put the headerless NSL-KDD text/CSV files here:

- `data/raw/KDDTrain+.txt`
- `data/raw/KDDTest+.txt`

The starter assumes the standard 43-column layout: 41 features, `label`, and `difficulty`. If your Kaggle download uses different filenames, includes a different header, or has a modified schema, inspect it first and adjust the loader rather than forcing it into this schema.

The University of New Brunswick dataset page describes the standard KDDTrain+ and KDDTest+ files and their label/difficulty fields: https://www.unb.ca/cic/datasets/nsl.html. The page currently notes that the original download is no longer available; use a Kaggle mirror only after checking its provenance and column layout.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate        # Linux/macOS
# .venv\\Scripts\\activate     # Windows PowerShell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## First development task: verify the dataset

1. Download the standard training and testing files from the chosen Kaggle source.
2. Put them in `data/raw/` with the expected filenames.
3. Run:

```bash
python -m src.inspect_dataset
```

4. Record the actual row counts, column count, class distribution, missing values, duplicate rows, and any schema differences in your report.

## Planned repository layout

```text
netguard-starter/
├── data/
│   └── raw/                 # Original dataset; do not commit large source files
├── notebooks/
│   └── 01_data_acquisition.ipynb
├── src/
│   ├── __init__.py
│   ├── schema.py
│   └── inspect_dataset.py
├── models/                  # Saved preprocessor + trained model
├── reports/                 # Metrics, plots, experiment notes
├── app.py                   # Streamlit app (next development stage)
├── requirements.txt
└── README.md
```

## Rules for a valid experiment

- Keep KDDTest+ untouched until final evaluation.
- Split only the training file into train/validation when tuning.
- Fit imputers, scalers, encoders, and SMOTENC using training data only.
- Apply SMOTENC only to the training partition. Never resample validation or test data.
- Use `protocol_type`, `service`, and `flag` as categorical features; do not treat category codes as continuous magnitudes.
- `difficulty` is dataset metadata, not one of the 41 input features; exclude it from model input.
- Report recall for the `anomaly` class alongside precision, F1-score, and false negatives.
- Do not claim the model detects every zero-day attack or operates on live packets.

## Next milestones

1. Data audit and EDA.
2. Cleaning and preprocessing.
3. SMOTENC + XGBoost training and validation.
4. Final evaluation on the untouched KDDTest+ file.
5. Streamlit dashboard and unlabeled CSV scanner.
6. Integration testing, presentation, and documentation.
