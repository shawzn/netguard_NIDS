Place the original NSL-KDD files in this directory:

- KDDTrain+.txt
- KDDTest+.txt

Do not commit the dataset files to Git unless the dataset source/license and repository policy have been checked. The loader expects the standard 43-column format (41 features + label + difficulty).
