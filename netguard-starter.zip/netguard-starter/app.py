import streamlit as st

st.set_page_config(page_title="NetGuard | NIDS", page_icon="🛡️", layout="wide")
st.title("NetGuard")
st.caption("Machine Learning-Based Network Intrusion Detection System")
st.info(
    "Dashboard scaffold. Dataset analysis, XGBoost evaluation, and CSV scanning "
    "will be connected after the training pipeline is validated."
)
